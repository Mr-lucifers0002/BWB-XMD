<p align="center">
  <a href="https://git.io/typing-svg">
    <img src="https://readme-typing-svg.demolab.com?font=Black+Ops+One&size=80&pause=1000&color=87CEEB&center=true&vCenter=true&width=1000&height=200&lines=BWB-XMD;UPDATION+2025;BY+PRINCE" alt="Typing SVG" />
  </a>
</p>
  
--- 

<a><img src='https://files.catbox.moe/6xk8eh.jpg'/></a>

>1.FORK THE REPO 
[![Fork Repo](https://img.shields.io/badge/Fork-Repo-222222?style=for-the-badge&logo=github)](https://github.com/Princetech-bwb/BWB-XMD/fork)



> **2. PAIR CODE SESSION ID**

<a href='https://b-w-b-session-id.onrender.com' target="_blank">
  <img alt='Pairing Code' src='https://img.shields.io/badge/Get%20Pairing%20Code-orange?style=for-the-badge&logo=opencv&logoColor=black'/>
</a>
<br> 



---

>3. HEROKU</h3>
<p style="text-align: center; font-size: 1.2em;">


>[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://dashboard.heroku.com/new?template=https://github.com/Princetech-bwb/BWB-XMD)
<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>




4. RENDER</h4>
<p style="text-align: center; font-size: 1.2em;">
  
<p align="">
<a href='https://dashboard.render.com/web/new' target="_blank"><img alt='Heroku' src='https://img.shields.io/badge/-Render deploy-black?style=for-the-badge&logo=render&logoColot=white'/< width=150 height=28/p></a>
<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>

5. TALKDROVE FREE</h4>
<p style="text-align: center; font-size: 1.2em;">
  
<p align="">
<a href='https://host.talkdrove.com/dashboard/select-bot/prepare-deployment?botId=36' target="_blank"><img alt='Heroku' src='https://img.shields.io/badge/-TalkDrove ‎Deploy-6971FF?style=for-the-badge&logo=Github&logoColor=white'/< width=150 height=28/p></a>
  <a><img src='https://i.imgur.com/LyHic3i.gif'/></a>



6. RAILWAY</h4>
<p style="text-align: center; font-size: 1.2em;">

<p align="">
<a href='https://railway.app/new' target="_blank"><img alt='Heroku' src='https://img.shields.io/badge/-railway deploy-FF8700?style=for-the-badge&logo=railway&logoColor=white'/< width=150 height=28/p></a>
<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>


  >THANKS ALLAH🌏🌏🌏🌏🌏
